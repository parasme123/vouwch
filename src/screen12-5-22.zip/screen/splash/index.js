import Splash from "./splash";

export default Splash